#include <iostream>
#include <string>

using namespace std;
int main()
{
	int x, y, z, w;
	cout << "please, enter the values of x, y, z ,w ";
	cout << endl;
	cin >> x >> y >> z >> w;
	cout << "the values you entered are " << "x="<< x << " , y=" << y << " , z = "<< z << ", w=" <<w << endl;
	
	cout << "a)  x==z: " << endl;
	if (x == z)
	{
		cout << "evulation for x==z is true  or 1" << endl;
	}
	else
		cout << "evulation for x==z is false or 0" << endl;
	

	cout << "b) (z-25) != (y+10) :  ";

		if ((z - 25) != (y + 10))
	    {
			cout << "evulation for ((z - 25) != (y + 10)) is true  or 1" << endl;
		}
		else
			cout << "evulation for ((z - 25) != (y + 10)) is false or 0" << endl;
	

		cout << "c) w>=z " << endl;
		if (w >= z)
		{
			cout << "evulation for (w >= z) is true or 1 " << endl;
		}
		else
			cout << "evulation for (w >= z) is false or 0 " << endl;


	cout << "d) (w<x)&&(y>z): " << endl;
	if ((w < x) && (y > z))
	{
		cout << "evulation for (w<x)&&(y>z) is true or 1 " << endl;
	}
	else
		cout << "evulation for (w<x)&&(y>z) is false or 0 " << endl;



	cout << "e) (z+11) != (11+z): " << endl;
	if ((z + 11) != (11 + z))
	{
		cout << "evulation for (z+11) != (11+z) is true or 1 " << endl;
	}
	else
		cout << "evulation for (z+11) != (11+z) is false or 0 " << endl;




	system("pause");
	return 0;
}