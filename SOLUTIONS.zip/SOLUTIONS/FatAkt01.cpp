#include<iostream>
using namespace std;
int main()
{
	cout << "This is my first programing" << endl;
	system("Pause");
	return 0;

}