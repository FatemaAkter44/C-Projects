#include <iostream>
//this program uses if and else statements 
using namespace std;


int main()
{
	double num;
	cout << "Enter a positive or Negative number, or enter Zero :  ";
	cin >> num;
	cout << endl;
	cout << "the number you just enter is :  " << num << " , and for the your info this is a ";

	if (num == 0)
		cout << "Zero which means lack of value" << endl;
	else if (num > 0)
		cout << "Positive number, greater than Zero" << endl;
	else
		cout << "Negative number or less than zero"
		<< endl;
	system("pause");
	return 0;


}