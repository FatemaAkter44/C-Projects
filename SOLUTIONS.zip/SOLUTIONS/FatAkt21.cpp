#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	double first_number, second_number;
	char math_operator;

	cout << fixed << noshowpoint << setprecision(2);

	cout << "enter two numbers:  ";
	cin >> first_number >> second_number;
	cout << endl;

	cout << "Enter operator: + (addition  - (substration), * (multiplication), / (division): ";
	cin >> math_operator;
	cout << endl;

	cout << first_number << " " << math_operator << " " << second_number << " = ";

	switch (math_operator)
	{
	case '+':
		cout << first_number + second_number << endl;
		break;
	case '-':
		cout << first_number - second_number << endl;
		break;
	case '*':
		cout << first_number * second_number << endl;
		break;
	case '/':
		if (second_number != 0)
			cout << first_number / second_number << endl;
		else
			cout << "ERROR \nCannot divide by Zero " << endl;

		break;
	default:
		cout << "Illegal Opeartion" << endl;
	}
	system("pause");
	return 0;


}