#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	double cost;
	double area;
	double bagSize;

	cout << fixed << showpoint << setprecision(2) << endl;

	cout << "Enter the amount of fertilizer, in pounds, " << "in one bag: ";
	cin >> bagSize;
	cout << endl;

	cout << "Enter the cost of the " << bagSize
		<< " pound fertilizer bag: ";
	cin >> cost;
	cout << endl;

	cout << "Enter the area in square feet, that can be  fertilized by one bag: ";
	cin >> area;
	cout << endl;

	cout << "The cost of the fertilizer per pound is: $"
		<< cost / bagSize << endl;

	cout << "The cost of fertilizing per square foot is: $"
		<< cost / area << endl;
	system("pause");

	return 0;
}