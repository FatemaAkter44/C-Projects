// This program illustates how output statement work

#include <iostream>
using namespace std;

int main()
{

	int a, b;
	a = 65;
	b = 78;

	cout << 29 / 4 << endl;
	cout << 3.0 / 2 << endl;
	cout << "hello there. \n";
	cout << 7 << endl;
	cout << 3 + 5 << endl;
	cout << "3 + 5";
	cout << " **";
	cout << endl;
	cout << 2 + 3 * 6 << endl;
	cout << "a" << endl;
	cout << a << endl;
	cout << b << endl;
	system("pause");
	return 0;

}