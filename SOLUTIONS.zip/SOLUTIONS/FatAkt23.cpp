#include <iostream>
#include <string>
using namespace std;

int main()
{
	int s, t, r, u;
	cout << "Please Enter the value of s, t, r, u:  ";
	cin >> s >> t >> r >> u;
	cout << endl;

	cout << "the  values you just Entered are:  " <<"s="<< s << ", t="<< t <<", r=" << r <<", u=" << u << endl;
	cout << "the logical operation will be performed by using expresssions bellow " << endl;


	if ((s > t) && (r < u)) 
		cout << "the expression (s > t) && (r < u) will evalute to 1 (YES)  " << endl;
	
	else
		cout << "the ezxpression (s > t) && (r < u) will evalute to 0 (NO) " << endl;


	if (!((s - u) < (t + r)))
		cout << "the expression  ! ((s-u) < (t + r)) will evalute to 1 (YES) " << endl;
	else
		cout << "the expression ! ((s - u) < (t + r)) will evalute to 0 (NO)  " << endl;

	system("pause");
	return 0;

}