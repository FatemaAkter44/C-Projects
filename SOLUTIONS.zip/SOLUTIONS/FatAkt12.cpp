#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	double kilograms;
	double pounds;


	cout << fixed << showpoint << setprecision(2) << endl;

	cout << " What is the weight in Kilograms: ";
	cin >> kilograms;
	cout << endl;

	pounds = 2.2 * kilograms;
	cout << " The Weight you Enter in pounds is: = " << pounds << "   lbs" << endl;
	system("pause");
	return 0;
}