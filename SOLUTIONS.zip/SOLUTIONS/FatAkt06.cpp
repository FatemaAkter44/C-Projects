#include<iostream>
using namespace std;

const double local_tax_rate = 0.08875;
const double credit_perc = 0.05;

int main()
{
	int Gross, Non_taxable, Taxable;
	double Pen_and_int, Pre_tax, Vendor_credit, Tax_due;

	cout << "enter two integer, one for Gross" << " one for Nontaxable: ";
	cin >> Gross >> Non_taxable;
	cout << endl;

	cout << "enter the penalties and interest at this time: ";
	cin >> Pen_and_int;
	cout << endl;
	
	cout << "the number you enter are " << Gross << " for gross sell and " << Non_taxable << "sales exempt from taxes. penalties and interest  " << Pen_and_int << endl;
	
	Taxable = Gross - Non_taxable;
	cout << " the taxable of the sale for this quater is =  " << Taxable << endl;

	Pre_tax = Taxable * local_tax_rate;
	cout << " The pre_tex for the qurter is =" << Pre_tax << endl;

	Vendor_credit = Pre_tax * credit_perc;
	cout << " the amount to be creadider to vendor for this quarter is ="<< Vendor_credit << endl;

	Tax_due = (Pre_tax - Vendor_credit) + Pen_and_int;
	cout << " the final calculation of the sales taxes due for this quarter is = " << Tax_due << endl;

	system("pause");
	return 0;

}