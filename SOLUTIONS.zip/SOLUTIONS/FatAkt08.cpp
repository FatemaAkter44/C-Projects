// This program illustrates how integral expressons are
// evaluated.

#include <iostream>

using namespace std;

int main()
{

	cout << "3*2 / 2*2 + 5.5*2 = " << 3*2 / 2*2  + 5.5*2 << endl;
	cout << "15.6*2 / 2*2 + 5*2 = " << 15.6 * 2 / 2 * 2 + 5 * 2 << endl;
	cout << "4*2 + 5*2 / 2.0*2 = " << 4 * 2 + 5 * 2 / 2.0 * 2 << endl;
	cout << "4*2 * 3*2 + 7*2 / 5*2 - 25.5*2 = " << 4 * 2 * 3 * 2 + 7 * 2 / 5 * 2 - 25.5 * 2 << endl;

	system("pause");
	return 0;
}