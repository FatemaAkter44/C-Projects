#include <iostream>
using namespace std;
int GROSS, NON_TAXABLE, TAXABLE;
double local_tax_rate, credit_perc;
double pen_and_int, tax_due;

int main()
{

	cout << "Enter the total paid for taxes... ";
	cin >> tax_due;
	cout << endl;
	cout << "the amount of the non-taxable sales... ";
	cin >> NON_TAXABLE;
	cout << endl;
	cout << "what is the local taxe rate according to the jurisdiction?... ";
	cin >> local_tax_rate;
	cout << endl;
	cout << "enter the vendor credit rate according to the state .. ";
	cin >> credit_perc;
	cout << endl;
	cout << "Enter the penalties and interest paid at the time...";
	cin >> pen_and_int;
	cout << endl;

	cout << "the total paid taxes in this period is: " << tax_due;
	cout << endl;
	cout << "the amount of the non_taxable sales in this period is: " << NON_TAXABLE;
	cout << endl;
	cout << "the local tax rate according to the jurisdictrion is:  " << local_tax_rate;
	cout << endl;
	cout << "the vendor credit rate according to the state: " << credit_perc;
	cout << endl;
	cout << "the interest and penalties for late submision is :  " << pen_and_int;
	cout << endl;
	cout << "...........................................................";
	cout << endl;
	GROSS = (tax_due + local_tax_rate * NON_TAXABLE - local_tax_rate * credit_perc *NON_TAXABLE - pen_and_int) / ((1 - credit_perc)*local_tax_rate);
	cout << "the gross sales for this period of time is " << GROSS << endl;
	cout << ".....................................";
	cout << endl;
	system("pause");
	return 0;

}
