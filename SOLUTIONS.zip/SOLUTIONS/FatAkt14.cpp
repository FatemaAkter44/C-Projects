#include <iostream>

using namespace std;
int main()
{
	char ch;
	cout << "Line 1: Enter a String: ";
	cin.get(ch);
	cout << endl;
	cout << "Line 4: After first cin.get(ch); "
		<< "ch= " << ch << endl;


	cin.get(ch);
	cout << "Line 6: After Second cin.get(ch); "
		<< "ch = " << ch << endl;


	cin.putback(ch);
	cin.get(ch);
	cout << "Line 9: After putback and then "
		<< "cin.get(ch); ch  = " << ch << endl;
	ch = cin.peek();
	cout << "Line 11: After cin.peek(); ch= "
		<< ch << endl;
	cin.get(ch);
	cout << " Line 13: After cin.get(ch); ch = "
		<< ch << endl;


	cin.get(ch);
	cout << "Line 14: After cin.get(ch) ch = "
		<< ch << endl;


	cin.get(ch);
	cout << "Line 16: After cin.get(ch); ch = "
		<< ch << endl;


	cin.putback(ch);
	cin.get(ch);
	cout << "Line 18: After putback and then "
		<< "cin.putback(ch); ch = " << ch << endl;


	ch = cin.peek();
	cout << "Line 11: After cin.peek(); Ch = "
		<< ch << endl;


	cin.putback(ch);
	cin.get(ch);
	cout << "Line 21: After Putback and then "
		<< "cin.get(ch); ch = " << ch << endl;





	system("pause");
	return 0;
}