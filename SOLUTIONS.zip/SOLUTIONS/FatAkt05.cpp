#include <iostream>

using namespace std;

//named constants
const double kilobits_per_bits = 0.001;
const int bits_per_bytes = 8;

int main()
{
	//declare variables
	int bytes, bits;
	int totalbits;
	double kilobits;

	//Statements: Step 1 - Step 7
	cout << "Enter two integers, one for bytes and "
		<< "one for bits: ";                  //Step 1
	cin >> bytes >> bits;                      //Step 2
	cout << endl;

	cout << "The numbers you entered are " << bytes
		<< " for bytes and " << bits
		<< " for bits. " << endl;        //step 3

	totalbits = bits_per_bytes * bytes + bits;     //Step 4

	cout << "The total number of bits = "
		<< totalbits << endl;                 //step 5

	kilobits = kilobits_per_bits * totalbits;  //step 6

	cout << "The number of kilobits = "
		<< kilobits << endl;
	system("pause");

	return 0;
}